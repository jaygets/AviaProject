﻿namespace Session1_Tankaeva
{


    partial class Session2_TankaevaDataSet
    {
    }
}
